<!DOCTYPE html>
<html lang="en">
  <?php include 'incl/head.php';?>
  <body style="background-color: #ffffff;">
        <div class="container" role="main">
          <!-- top tiles -->
          <div class="row col-md-12 col-sm-12">
								<div class="col-md-12">
									<video id="preview" width="50%" height="70%" style="border:5px solid #2baab1;border-radius:10px"></video>
								</div>
								<div class="col-md-12">
								
									<label for="camera-select">Select Camera:</label>
									<select id="camera-select" class="form-control"></select><br>
										<label>QR Value</label>
									<input type="text" name="name" id="text" placeholder="Scan QR code" class="form-control">
                </div>
          <!-- /top tiles -->
            </div>
        </div>
        <audio id="success-sound" src="scan/b.mp3" hidden></audio>
        <audio id="error-sound" src="scan/e.mp3" hidden></audio>
        <audio id="i-sound" src="scan/i.mp3" hidden></audio>
        <script>
  let scanner = new Instascan.Scanner({ video: document.getElementById('preview') });
  let cameras = [];
  Instascan.Camera.getCameras().then(function (availableCameras) {
    cameras = availableCameras;
    if (cameras.length > 0) {
      let cameraSelect = document.getElementById('camera-select');
      cameras.forEach(function (camera, index) {
        let option = document.createElement('option');
        option.value = index;
        option.text = camera.name;
        cameraSelect.appendChild(option);
      });
      scanner.start(cameras[0]);
    } else {
      alert('No cameras found');
    }
  }).catch(function (e) {
    console.error(e);
  });
  document.getElementById('camera-select').addEventListener('change', function (event) {
    let selectedCameraIndex = event.target.value;
    if (selectedCameraIndex >= 0 && selectedCameraIndex < cameras.length) {
      scanner.start(cameras[selectedCameraIndex]);
    }
  });
  scanner.addListener('scan', function (content) {
    // Trim the value after the word "name"
    let index = content.indexOf("name=");
    if (index === -1) {
      swalWithSound('error', 'Invalid QR value!');
      return;
    }
    let trimmedValue = content.substring(index + 5);
    if (trimmedValue.trim().length === 0) {
      swalWithSound('error', 'Invalid QR value!');
      return;
    }
          
    $("#text").val(trimmedValue.replace(/Ã/g, 'Ñ'));

    $.ajax({
      type: 'POST',
      url: 'scanned_update.php',
      data: { name: trimmedValue },
      success: function(response) {
        console.log(JSON.parse(response));
        var obj_res = JSON.parse(response);
        swalWithSound(obj_res.icon, obj_res.message);
      },
      error: function(xhr, status, error) {
        var icon = 'error';
        var title = xhr + ' - ' + status + ' - ' + error;
        swalWithSound(icon, title);
      }
    });
  });
  function swalWithSound(icon, title) {
    var sound;
    if (icon === 'success') {
      sound = document.getElementById('success-sound');
    } 
      else if(icon === 'error' && title === 'Invalid QR value!'){
      sound = document.getElementById('i-sound');
    }
    else {
      sound = document.getElementById('error-sound');
    }
    sound.play();
    Swal.fire({
      icon: icon,
      title: title,
      showConfirmButton: false,
      allowOutsideClick: false
    });
    setTimeout(function() {
      Swal.close();
    }, 1000);
  }
</script>
      <?php include 'incl/south.php';?>
