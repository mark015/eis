<?php include 'incl/north.php';?>
        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row col-md-12 col-sm-12" style="display: inline-block;" >
          <div class="x_content" style="display: block;">
          <div class="col-md-5"><label>Date</label>
<input value="<?php echo date('F')?>" type="month" class="form-control col-md-12" style="margin-bottom:10px"/>
</div>
<div class="col-md-2">
<label style="opacity:0.0">Search</label>
<button type="button" class="btn btn-secondary form-control" data-toggle="modal" data-target=".bs-example-modal-lg">Search</button>
</div>
<div class="col-md-12">
</div>

        </div>
          <!-- /top tiles -->
            </div>
        </div>
      <?php include 'incl/south.php';?>
