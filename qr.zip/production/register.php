
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Toboso QR Attendance</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="../vendors/animate.css/animate.min.css" rel="stylesheet">
    <link rel="stylesheet" href="vendors/swal/dist/sweetalert2.min.css">
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

  </head>

  <body class="login" style="background-color:#ffffff;">
    <div>
    <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form id="registerForm">
              <h1>Register</h1>
              <div>
                <input type="text" id="username" name="username" class="form-control" placeholder="Username" required="" />
              </div>
              <div>
                <input type="email" id="email" name="email" class="form-control" placeholder="Email" required="" />
              </div>
              <div>
                <input type="password" id="password" name="password" class="form-control" placeholder="Password" required="" />
              </div>
              <div>
                <button class="btn btn-secondary" type="submit" value="Register">Log in</button>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <div class="clearfix"></div>
                <br />

                <div>
                  <hp><i class="fa fa-file-code-o"></i> Developed By <strong>TechzQuad</strong></p>
                  <p>©2016 All Rights Reserved. We Are The Solution</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
    <script>
    $(document).ready(function() {
        $('#registerForm').submit(function(event) {
            event.preventDefault();
            var username = $('#username').val();
            var password = $('#password').val();
            var email = $('#email').val();
            $.ajax({
                type: 'POST',
                url: 'process/register_process.php',
                data: {username: username, password: password, email: email},
                success: function(response) {
                    // Check if registration was successful
                    if(response.trim() == 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Registration Successful',
                            text: 'You have successfully registered.',
                            showConfirmButton: false,
                            timer: 2000 // Close the alert after 2 seconds
                        });
                    } else {
                        // If registration failed, show error message
                        Swal.fire({
                            icon: 'error',
                            title: 'Registration Failed',
                            text: response // Assuming response contains error message
                        });
                    }
                }
            });
        });
    });
</script>

    <script src="../vendors/swal/dist/sweetalert2.min.js"></script>
  </body>
</html>
