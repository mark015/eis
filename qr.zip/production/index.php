<?php include 'incl/north.php';?>
        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row col-md-12 col-sm-12" style="display: inline-block;" >
          <div class="row">
                      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-users"></i>
                          </div>
                          <div class="count">179</div>
                          <h3>Users</h3>
                        </div>
                      </div>
                      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-smile-o"></i>
                          </div>
                          <div class="count">179</div>
                          <h3>Employees</h3>
                        </div>
                      </div>
                      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-sort-amount-desc"></i>
                          </div>
                          <div class="count">179</div>
                          <h3>Departments</h3>
                        </div>
                      </div>
                    </div>
          <div class="x_content" style="display: block;">
<ul class="nav nav-tabs bar_tabs" id="myTab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="emp-tab" data-toggle="tab" href="#emp" role="tab" aria-controls="emp" aria-selected="true">Employees</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="dept-tab" data-toggle="tab" href="#dept" role="tab" aria-controls="dept" aria-selected="false">Department</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="etype-tab" data-toggle="tab" href="#etype" role="tab" aria-controls="etype" aria-selected="false">Employee Type</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="users-tab" data-toggle="tab" href="#users" role="tab" aria-controls="users" aria-selected="false">Users</a>
  </li>
</ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade active show" id="emp" role="tabpanel" aria-labelledby="emp-tab">
    <?php include 'incl/employees.php';?>
    <?php include 'incl/modals/add_employee.php';?>
  </div>
  <div class="tab-pane fade" id="dept" role="tabpanel" aria-labelledby="dept-tab">
  <?php include 'incl/department.php';?>
  </div>
  <div class="tab-pane fade" id="etype" role="tabpanel" aria-labelledby="etype-tab">
  <?php include 'incl/emp_type.php';?>
  </div>
  <div class="tab-pane fade" id="users" role="tabpanel" aria-labelledby="users-tab">
  <?php include 'incl/users.php';?>
  </div>
</div>
</div>
        </div>
          <!-- /top tiles -->
            </div>
      <?php include 'incl/south.php';?>
