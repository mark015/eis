<?php 
include 'include/config.php';
session_start(); 
if (isset($_POST['name'])) {
    $ivn = $_POST['name'];
    $replacement = 'Ñ';
    $characters_to_replace = 'Ã';
    $vn = str_replace($characters_to_replace, $replacement, $ivn);
    $tv = date('h:i:s a');
    $remarks = 'Returned';
    $stat = 'Voted';
    if ($result = checkSupporter($vn)) {
        while ($row = $result->fetch_assoc()) {
            if ($row['status'] == $stat) {
                echo json_encode([
                    'icon' => 'error',
                    'message' => $vn . ' is already voted!'
                ]);
            } else {
                if (updateSupporter($vn, $stat, $remarks, $tv) == 'success') {
                    
                    $sesh = $_SESSION['id'];
                    $cf = "INSERT INTO `scanner_count`(`id`, `scanner_id`, `total`, `amount`) VALUES ('', '$sesh', '1', '1')";
                    $conn->query($cf);
                    
                    echo json_encode([
                        'icon' => 'success',
                        'message' => $vn . ' data was updated!'
                    ]);
                }
            }
        }
    } else {
        echo json_encode([
            'icon' => 'error',
            'message' => $vn . ' does not exist!'
        ]);
    }
}
function checkSupporter($vn) {
    global $conn;
    $sql = "SELECT * FROM election_2023 WHERE name = '$vn'";
    $result = $conn->query($sql);
    return $result->num_rows > 0 ? $result : false;
}
function updateSupporter($vn, $stat, $remarks, $tv) {
    global $conn;
    $sesh = $_SESSION['id']; // Assign $_SESSION['id'] to $sesh
    $updateSql = "UPDATE election_2023 SET status = '$stat', remarks = '$remarks', time = '$tv' WHERE name = '$vn' AND pos != ''";
    return $conn->query($updateSql) === TRUE ? 'success' : 'error';
}?>
