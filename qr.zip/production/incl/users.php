<div class="col-md-6">
<button type="button" class="btn btn-secondary" data-toggle="modal" data-target=".bs-example-modal-lg">Add User</button>
</div>
<table class="table table-hover">
                      <thead>
                        <tr style="background-color:#2A3F54;color:#ffffff">
                          <th>Username</th>
                          <th>Email</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Mark</td>
                          <td>Otto@gg.me</td>
                          <td></td>
                        </tr>
                      </tbody>
                    </table>