<div class="col-md-6">
<input type="text" placeholder="search..." class="form-control col-md-12" style="margin-bottom:10px"/>
</div>
<div class="col-md-6">
<button type="button" class="btn btn-secondary" data-toggle="modal" data-target=".bs-example-modal-lg">Add Employee</button>
</div>
<table class="table table-hover">
                      <thead>
                        <tr style="background-color:#2A3F54;color:#ffffff">
                          <th>Picture</th>
                          <th>Name</th>
                          <th>Department</th>
                          <th>Employee Type</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row"><img src="images/img.jpg" alt="..." class="img-circle" style="width:30px;height:30px"></th>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td>@mdo</td>
                        </tr>
                      </tbody>
                    </table>