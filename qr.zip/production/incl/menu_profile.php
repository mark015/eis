  <div class="profile clearfix">
              <div class="profile_pic">
                <img src="images/off_logo.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>