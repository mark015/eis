     <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a href="index"><i class="fa fa-dashboard"></i>Dashboard</a></li>
                  <li><a href="dtr"><i class="fa fa-users"></i>DTR</a></li>
                  <li><a href="scanner"><i class="fa fa-credit-card"></i>Scan</a></li>
                </ul>
              </div>

            </div>