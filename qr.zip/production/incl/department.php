<div class="col-md-6">
<input type="text" placeholder="search..." class="form-control col-md-12" style="margin-bottom:10px"/>
</div>
<div class="col-md-6">
<button type="button" class="btn btn-secondary" data-toggle="modal" data-target=".bs-example-modal-lg">Add Department</button>
</div>
<table class="table table-hover">
                      <thead>
                        <tr style="background-color:#2A3F54;color:#ffffff">
                          <th>Department</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Mark</td>
                          <td>Otto</td>
                        </tr>
                      </tbody>
                    </table>