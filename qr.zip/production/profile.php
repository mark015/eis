<?php include 'incl/north.php';?>
        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row col-md-12 col-sm-12" style="display: inline-block;" >
          <div class="x_content" style="display: block;">
          <div class="x_content">
                    <div class="col-md-12 profile_left" style="margin-bottom:40px">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="images/picture.jpg" alt="Avatar" title="Change the avatar">
                        </div>
                      </div>
                      
                    </div>
                   
                    <div class="col-md-3">
                    <input type="text" name="username" class="form-control" placeholder="Username" required="" />
                    </div>
                    <div class="col-md-3">
                    <input type="text" name="email" class="form-control" placeholder="Email" required="" />
                    </div>
                    <button type="submit" class="btn btn-danger">Update</button>
                  </div>

        </div>
          <!-- /top tiles -->
            </div>
        </div>
      <?php include 'incl/south.php';?>
